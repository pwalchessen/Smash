# Support


Please ask questions and file bug descriptions [on the GitHub issuetracker for sourmash, dib-lab/sourmash/issues][0]


You can also ask questions of Titus at. [@ctitusbrown][1]

[0]:https://github.com/dib-lab/sourmash/issues
[1]:https://twitter.com/ctitusbrown/
