# The data subdir

Data files for various and sundry purposes.

The following files are used by the doctests in doc/ & may also be useful
for developers who are benchmarking:

```
GCF_000005845.2_ASM584v2_genomic.fna.gz
GCF_000006945.1_ASM694v1_genomic.fna.gz
GCF_000783305.1_ASM78330v1_genomic.fna.gz
```

CTB 6/16
