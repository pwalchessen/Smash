# demo notebook & data

This directory contains a bunch of demonstration data and a notebook to
run it all; please see [00-demo.ipynb](00-demo.ipynb).

You can run it in Jupyter Notebook by installing the notebook
(use the 'demo' extra, like so:

    pip install sourmash -e demo

) and then running `jupyter notebook` in this directory.

CTB 6/16.
